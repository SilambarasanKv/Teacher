package com.ahaguru.teacherahaguru;

import android.app.ActionBar;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class SignupFragment extends Fragment {

    Button buttonNext;

    TextView fullName, phoneNumber, emailAddress, subjects;

    EditText name, phone, email;

    boolean isAllFieldsChecked = false;

    String[] subLists = { "English","Chemistry","Mathematics","Biology"};

    private String bundleFullname;
    private final String bundleFullnameVAL = "bundleFullnameVAL";

    public SignupFragment() {

    }

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;


    public static SignupFragment newInstance(String param1, String param2) {
        SignupFragment fragment = new SignupFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_signup, container, false);

        buttonNext = v.findViewById(R.id.btnNext);

        fullName = v.findViewById(R.id.tvFullname);
        phoneNumber = v.findViewById(R.id.tvPhoneNumber);
        emailAddress = v.findViewById(R.id.tvEmailAddress);
        subjects = v.findViewById(R.id.tvSubjects);

        name = v.findViewById(R.id.etFullName);
        phone = v.findViewById(R.id.etPhoneNumber);
        email = v.findViewById(R.id.etEmailAddress);

        Spinner spin = (Spinner) v.findViewById(R.id.spinner);



        ArrayAdapter arrayAdapter = new ArrayAdapter(this.getActivity(), android.R.layout.simple_spinner_item, subLists);

        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(arrayAdapter);

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                isAllFieldsChecked = CheckAllFields();


                if (isAllFieldsChecked) {

//                    CodeFragment codeFragment = new CodeFragment();
//                    FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
//                    transaction.replace(R.id.mainLayout, codeFragment);
//                    transaction.commit();

                    ((MainActivity) getActivity()).getFragmentStateSaver().changeFragment(1);

                }



            }
        });

        return v;


    }

    private boolean CheckAllFields() {

        if(name.length() == 0) {
            name.setError("Your name is required");
            return false;
        }

        if(phone.length() < 10) {
            phone.setError("Enter the correct mobile number");
            return false;
        }

        else if(email.length() == 0) {
            email.setError("Your email address is required");
            return false;
        }


        return true;

    }


}