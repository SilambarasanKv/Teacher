package com.ahaguru.teacherahaguru;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import com.ahaguru.teacherahaguru.utils.FragmentStateSaver;

public class MainActivity extends AppCompatActivity {
    public FragmentStateSaver fragmentStateSaver;
    Toolbar toolbar;
    SignupFragment signupFragment;

    public FragmentStateSaver getFragmentStateSaver() {
        return fragmentStateSaver;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        fragmentStateSaver = new FragmentStateSaver(findViewById(R.id.mainLayout), getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                switch (position) {
                    case 0:
                        return new SignupFragment();
                    case 1:
                        return new CodeFragment();

                    case 2:
                        return new WaitingFragment();

                    case 3:
                        return new ApprovedFragment();

                    case 4:
                        return new RejectedFragment();

                    default:
                        return new SignupFragment();
                }
            }
        };
        fragmentStateSaver.changeFragment(0);

//        signupFragment = new SignupFragment();
//        FragmentManager fragmentManager = getSupportFragmentManager();
//
//        fragmentManager.beginTransaction().add(R.id.mainLayout, signupFragment).commit();



    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        //Save the fragment's instance
        getSupportFragmentManager().putFragment(outState, "signupFragment", signupFragment);
    }



}