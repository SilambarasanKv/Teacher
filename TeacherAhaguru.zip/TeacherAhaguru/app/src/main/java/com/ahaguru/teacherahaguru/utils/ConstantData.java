package com.ahaguru.teacherahaguru.utils;

public class ConstantData {
    public static int PENDING = 0;
    public static int APPROVED = 1;
    public static int REJECTED = 2;
}
