package com.ahaguru.teacherahaguru;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.ActionBar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ahaguru.teacherahaguru.utils.FragmentStateSaver;

public class CodeFragment extends Fragment {

    Button buttonSubmit;

    EditText code;

    boolean isAllFieldsChecked = false;

    public CodeFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_code, container, false);

        buttonSubmit = v.findViewById(R.id.btnSubmit);
        code = v.findViewById(R.id.etCode);

        code.setTransformationMethod(new AsteriskPasswordTransformationMethod());

        setHasOptionsMenu(true);

        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setHomeButtonEnabled(true);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                isAllFieldsChecked = CheckAllFields();

                if(isAllFieldsChecked) {

                    ((MainActivity) getActivity()).getFragmentStateSaver().changeFragment(2);
                }

            }
        });
        v.setFocusableInTouchMode(true);
        v.requestFocus();
        v.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                Log.i("tag", "keyCode: " + keyCode);
                if( keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    Log.i("", "onKey Back listener is working!!!");
//                    getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    SignupFragment signupFragment = new SignupFragment();
//                    getActivity().getSupportFragmentManager().beginTransaction()
//                            .add(signupFragment, "detail") // Add this transaction to the back stack (name is an optional name for this back stack state, or null).
//                            .addToBackStack(null)
//                            .commit();

//                    FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
//                    transaction.replace(R.id.mainLayout, new SignupFragment());
//                    transaction.addToBackStack(null);
//                    transaction.commit();


                    ((MainActivity) getActivity()).getFragmentStateSaver().changeFragment(0);

                    return true;
                }
                return false;
            }
        });

        return v;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if (item.getItemId() == android.R.id.home) {
            ((MainActivity) getActivity()).getFragmentStateSaver().changeFragment(0);
            return true;
        };
        return super.onOptionsItemSelected(item);
    }

    private boolean CheckAllFields() {

        if(code.length() < 8) {
            code.setError("Enter the correct code");
            return false;
        }

        return true;
    }

}